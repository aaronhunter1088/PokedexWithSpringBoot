package pokedex.controllers;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;
import pokedex.services.DarkmodeService;
import pokedex.services.GifService;
import pokedexapi.service.PokemonApiService;
import tools.jackson.databind.ObjectMapper;

@Controller
public class SearchController extends BaseController
{
    /* Logging instance */
    private static final Logger LOGGER = LogManager.getLogger(SearchController.class);

    @Autowired
    public SearchController(PokemonApiService pokemonService,
                            ObjectMapper objectMapper,
                            Environment environment,
                            DarkmodeService darkmodeService,
                            GifService gifService)
    {
        super(pokemonService, objectMapper, environment, darkmodeService, gifService);
    }

    @GetMapping("/search")
    public ModelAndView searchPage(ModelAndView mav)
    {
        LOGGER.info("/search page called");
        //mav.addObject("pokemonId", 0);
        mav.addObject("isDarkMode", isDarkMode = darkmodeService.isDarkmode());
        mav.setViewName("search");
        return mav;
    }
}
